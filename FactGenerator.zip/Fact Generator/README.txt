======================================================================
SETUP/INSTALL GUI-FactGen:
----------------------------------------------------------------------
1. Create Virtual Environment (conda create -n GUI-FactGen python=3.8)
2. Activate Virtual Environment (conda activate GUI-FactGen)
3. Run this command in terminal:    pip install GUI-FactGen
======================================================================



======================================================================
START/RUN GUI-FactGen:
----------------------------------------------------------------------
(With Virtual Environment activated in terminal):
4. cd /To/Package/Folder/.../FactGen
5. Run this command in terminal:    python FactGen.py
======================================================================



======================================================================
ADD/REMOVE facts: (Quick Directions)
----------------------------------------------------------------------
(With Virtual Environment activated in terminal):
1. cd down to ./FactGen/my/custom
2. Edit and save OriginalList.txt (each newline is a "fact")
3. Run this command in terminal:    python listConvert.py
======================================================================



======================================================================
ADD/REMOVE facts: (Longer Directions)
----------------------------------------------------------------------
1. To create your own list, just edit and save "OriginalList.txt". 
   Each new line will be a new value in your list...
   
2. In Command Prompt or Terminal, change your workinig directory (cd)
   to the folder that contains OriginalList.txt... basically go to 
   this package folder like this below

    cd /Path/To/Package/Folder/.../FactGen/my/custom

3. Now with your Virtual Environment created and activated, run 
   "listConvert.py" file by typing this command in terminal:

        python listConvert.py    

   You should now have a new python file called "factListModule.py".
   For example, if you change OriginalList.txt to the text below...:

        thisIsValueZero
        This entire line is the 2nd item in your list
        apple
        orange
        thing5

    the code inside the factListModule.py output file will be:
        --------------------------------------------------------------
        import os
        import sys


        factlist = ['thisIsValueZero\n', 'This entire line is the 2nd 
        item in your list\n', 'apple\n', 'orange\n', 'thing5']
        --------------------------------------------------------------

4. Now to see your own custom list in the GUI, go back/up two folders 
   (cd ../../) to the parent folder

5. Run it like the first time by typing this command in terminal:

       python FactGen.py
======================================================================
